package bpso;

import java.util.ArrayList;

/**
 * Created by Dazsta on 25/10/2015.
 */

public interface Goodness {
    double getGoodness(boolean[] position);
}

